# Sentinel Entropy Dashboard

This is a Streamlit web application for analyzing cosmic microwave background (CMB) data, extracting entropy waveforms, and detecting collapse anomalies.

## Features
- Upload `.FITS` files (e.g., Planck/LAMBDA/ACT maps)
- Extract entropy waveforms from CMB images
- Visualize entropy evolution over time
- Highlight Sentinel-predicted collapse risk zones
- Built to integrate with QGI/AGI systems

## Quick Start (Streamlit Cloud)
1. [Fork this repo on GitHub](https://github.com/)
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
3. Connect your GitHub
4. Select this repo and click 'Deploy'

## Manual Start (Local)
```bash
pip install -r requirements.txt
streamlit run sentinel_dashboard.py
```

## License
MIT — non-commercial use only (contact author for commercial license).
